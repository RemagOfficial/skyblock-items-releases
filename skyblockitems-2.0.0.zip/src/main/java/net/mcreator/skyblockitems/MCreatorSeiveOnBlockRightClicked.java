package net.mcreator.skyblockitems;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.block.Blocks;

@Elementsskyblockitems.ModElement.Tag
public class MCreatorSeiveOnBlockRightClicked extends Elementsskyblockitems.ModElement {
	public MCreatorSeiveOnBlockRightClicked(Elementsskyblockitems instance) {
		super(instance, 85);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorSeiveOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure MCreatorSeiveOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure MCreatorSeiveOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure MCreatorSeiveOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure MCreatorSeiveOnBlockRightClicked!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		if ((new ItemStack(Blocks.DIRT, (int) (1)).getItem() == ((entity instanceof LivingEntity)
				? ((LivingEntity) entity).getHeldItemMainhand()
				: ItemStack.EMPTY).getItem())) {
			if ((Math.random() < 0.25)) {
				if (!world.isRemote) {
					ItemEntity entityToSpawn = new ItemEntity(world, x, (1 + y), z, new ItemStack(MCreatorPebble.block, (int) (1)));
					entityToSpawn.setPickupDelay(10);
					world.addEntity(entityToSpawn);
				}
				if (entity instanceof PlayerEntity)
					((PlayerEntity) entity).inventory
							.clearMatchingItems(p -> new ItemStack(Blocks.DIRT, (int) (1)).getItem() == p.getItem(), (int) 1);
			}
		}
	}
}
