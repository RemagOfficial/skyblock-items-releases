package net.mcreator.skyblockitems;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.util.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.Entity;

@Elementsskyblockitems.ModElement.Tag
public class MCreatorStopCommandExecuted extends Elementsskyblockitems.ModElement {
	public MCreatorStopCommandExecuted(Elementsskyblockitems instance) {
		super(instance, 67);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorStopCommandExecuted!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((((entity instanceof ServerPlayerEntity) && (entity.world instanceof ServerWorld)) ? ((ServerPlayerEntity) entity)
				.getAdvancements()
				.getProgress(
						((MinecraftServer) ((ServerPlayerEntity) entity).server).getAdvancementManager().getAdvancement(
								new ResourceLocation("skyblockitems:skyblockitemsadv"))).isDone() : false)) {
			if (!entity.world.isRemote && entity.world.getServer() != null) {
				entity.world
						.getServer()
						.getCommandManager()
						.handleCommand(entity.getCommandSource().withFeedbackDisabled().withPermissionLevel(4),
								"advancement revoke @p from skyblockitems:skyblockitemsadv");
			}
		}
	}
}
