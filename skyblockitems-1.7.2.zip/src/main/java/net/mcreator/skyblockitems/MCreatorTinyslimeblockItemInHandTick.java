package net.mcreator.skyblockitems;

import net.minecraft.world.World;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

@Elementsskyblockitems.ModElement.Tag
public class MCreatorTinyslimeblockItemInHandTick extends Elementsskyblockitems.ModElement {
	public MCreatorTinyslimeblockItemInHandTick(Elementsskyblockitems instance) {
		super(instance, 28);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorTinyslimeblockItemInHandTick!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure MCreatorTinyslimeblockItemInHandTick!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		World world = (World) dependencies.get("world");
		if ((entity.isSneaking())) {
			world.addParticle(ParticleTypes.ITEM_SLIME, (entity.posX), (entity.posY), (entity.posZ), 0, 1, 0);
		} else {
			if (entity instanceof LivingEntity)
				((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.JUMP_BOOST, (int) 1, (int) 0, (false), (false)));
		}
	}
}
