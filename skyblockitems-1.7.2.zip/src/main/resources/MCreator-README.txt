=== MCreator Mod Distribution License 1.0 ===

This mod was made using a free version of MCreator Minecraft mod maker (https://mcreator.net/).
Mods made with a free version of MCreator are covered by MCreator Mod Distribution License.

This license requires the following:

1. Each distribution of the exported mod file(s) is covered by this license and must retain an
   unchanged copy of this license file.
2. The mod can only be used for non-commercial purposes and can only be distributed for free.
3. Mod author and end users are not allowed to remove MCreator branding/credits from the mod
   (e.g. renaming files, editing source code or do any other changes that would hide or cover
   that the mod was made with/using MCreator)
4. The mod author is required to abide any other laws, licenses and terms that apply to them
   as a Minecraft mod/add-on author (for example Minecraft EULA and Minecraft Forge license)
5. The author must follow all the terms and meet all the requirements listed in MCreator's
   License terms (EULA) that were provided with the version of MCreator the author used to
   make and export this mod

Full license for MCreator 2020.1, which was used to make and export this mod, can be found
   on https://mcreator.net/repository/2020.1/LICENSE
Full distribution terms are described in the section "Mods made with MCreator" in MCreator
License agreement. This mod is covered by the terms and conditions described in the License
agreement found on the link above.

This mod was built and exported on 25. 01. 2020 using MCreator 2020.1.